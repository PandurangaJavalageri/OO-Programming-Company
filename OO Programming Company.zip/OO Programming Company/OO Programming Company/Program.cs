﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace OO_Programming_Company
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Company company = new Company();

            Employee employee1 = new Employee();
            employee1.Name = "pandu";
            employee1.Age = 30;
            employee1.Experience = 5;
            employee1.Basic = 500000;
            employee1.Address = "Gadag";
            employee1.EmpId=1;

            Employee employee2 = new Employee();
            employee2.Name = "Amogh";
            employee2.Age = 30;
            employee2.Experience = 5;
            employee2.Address = "Belagavi";
            employee2.EmpId = 2;
            employee2.Basic = 600000;

            Employee employee3 = new Employee();
            employee3.Name = "Sudeep";
            employee3.Age = 30;
            employee3.Experience = 5;
            employee3.Address = "Bagalkot";
            employee3.EmpId = 3;
            employee3.Basic = 700000;


            Customer customer1 = new Customer();
            customer1.CustomerId = 1;
            customer1.Email = "abc@gmail.com";
            customer1.Age = 30;
            customer1.Address = "hubli";
            customer1.Name = "Name";
          
            Customer customer2 = new Customer();
            customer2.CustomerId = 2;
            customer2.Age = 30;
            customer2.Email = "abcd@gmail.com";
            customer2.Address = "hadagli";
            customer2.Name = "Name";

            Branch registered=new Branch();
            Branch corporate=new Branch();
            company.list.Add(registered);
            company.list.Add(corporate);
            company.customers.Add(customer1);
            company.customers.Add(customer2);
            company.employees.Add(employee3);
            company.employees.Add(employee1);   
            company.employees.Add(employee2);
            company.GetEmployee(2);
            Console.WriteLine($" {company.GetTotalCustomers()}");
            Console.WriteLine($"{company.GetTotalSalaryPayout()}");
            Console.WriteLine($"{company.GetTotalCustomers()}");
          

        }
    }
    public class Company
    {
        public List<Branch> list {  get; set; }= new List<Branch>();
        public  List<Employee> employees { get; set; } = new List<Employee>();
        public List<Customer> customers { get; set; }=new List<Customer>();

        public string Name { get; set; }    
        public DateTime IncorporationDt { get; set; }
        public Employee GetEmployee (int EmpID)
        {
           foreach (Employee emp in employees) 
           {
                if(emp.EmpId == EmpID)
                {
                    Console.WriteLine(emp.Name);
                    return emp;
                }
           }
            Console.WriteLine("employee not found");
            return null;
        }
       public double GetTotalSalaryPayout()
        {
            double total = 0;
            foreach (Employee emp in employees)
            {
                total += emp.GetSalary();
            }
            return total;   
        }
        public int GetTotalCustomers() { return customers.Count; }
        public int GetTotalEmployees() 
        {  


            return employees.Count;
        }

    }
    public class Branch
    {

    }
    public interface Human
    {
        string Name { get; set; }
        int Age { get; set; }
        string Address { get; set; }
    }
    public class Person:Human
    {
        public string Name { get; set; }
        public int Age {  get; set; }
        public string Address {  get; set; }

    }
    public class Employee :Human
    { 
        Person person =new Person();
        public string Name { get; set; }
        public int Age { get; set; }
        public string Address { get; set; }
        public void hi()
        {
            Human h1 = person;
            Name = h1.Name;
            Age= h1.Age;
            Address = h1.Address;
        }
        public int EmpId {  get; set; }
        public double Basic {  get; set; }
        public double Experience {  get; set; }
        public double GetSalary()
        {
           return Basic+SalaryCalculator.CalculateSalary(Experience,Basic);
        }
    }
    public class Customer:Human
    {
        Person person1 = new Person();
        public string Name { get; set; }
        public int Age { get; set; }
        public string Address {  get; set; }
        public void hi()
        {
            Human h1 = person1;
            Name = h1.Name;
            Age = h1.Age;
            Address = h1.Address;
        }
        public int CustomerId { get; set; } 
        public string Email {  get; set; }
    }
    public class SalaryCalculator
    {
        public  static double CalculateSalary(double Experience,double Basic)
        {
            double percent = 0;
            if(Experience <=2) 
            {
                percent = 30;
            }
            else if(Experience<=4) 
            {
                percent = 40;
            }
            else if(Experience<=6)
            {
                percent = 50;
            }
            else
            {
                percent = 65;
            }
            return  (Basic*percent)/100;
            
        }
    }
}
